import pygame
import sys
from pygame.locals import *
from pygame import mixer

pygame.init()
pygame.mixer.init()

#Fonts and Font Sizes for the display screens 
font20 = pygame.font.Font('freesansbold.ttf', 20)
font40=pygame.font.Font('freesansbold.ttf', 40)
font10=pygame.font.Font('freesansbold.ttf', 15)

#Intializing the colors used in the game 
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
PINK = (255, 182, 193)
HOTPINK = (250, 10, 160)
DARKPINK = (200, 50, 120)
LIGHTPINK = (255, 100, 180)

# Basic parameters of the screen
WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Brick Breaker")

#Waiting 60 seconds for the displays 
clock = pygame.time.Clock()
FPS = 60

#Music for the game 
mixer.init()
mixer.music.load("Dance The Night.mp3")


#The class for the object(the striker) that the user moves to collide with the ball 
class Striker:
     # Take the initial position, dimensions, speed and color of the striker object
    def __init__(self, posx, posy, width, height, speed, color):
        self.posx = posx
        self.posy = posy
        self.width = width
        self.height = height
        self.speed = speed
        self.color = color
        # Rect that is used to control the position and collision of the striker object
        self.geekRect = pygame.Rect(posx, posy, width, height)
        # Object that is blit on the screen: initializing the object image 
        self.geek = pygame.draw.rect(screen, self.color, self.geekRect)

    # Used to display the object on the screen
    def display(self):
        self.geek = pygame.draw.rect(screen, self.color, self.geekRect)

    #Restrictions of the striker in terms of movement 
    def update(self, xFac):
        
        # Restricting the striker to be below the top surface of the screen
        self.posx = self.posx + self.speed * xFac

        if self.posx <= 0:
            self.posx = 0
            # Restricting the striker to stay in the screens view (can't go past the right or left boundaries)
        elif self.posx + self.width >= WIDTH:
            self.posx = WIDTH - self.width

        # Updating the rect with the new values
        self.geekRect = (self.posx, self.posy, self.width, self.height)

    def displayScore(self, text, score, x, y, color):
        text = font20.render(text + str(score), True, color)
        textRect = text.get_rect()
        textRect.center = (x, y)
        screen.blit(text, textRect)

    def getRect(self):
        return self.geekRect

#The class for the ball object
class Ball:
    #Intitalizing the balls position, radius, speed, and color 
    def __init__(self, posx, posy, radius, speed, color):
        self.posx = posx
        self.posy = posy
        self.radius = radius
        self.speed = speed
        self.color = color
        self.xFac = 1
        self.yFac = -1
        self.ball = pygame.draw.circle(screen, self.color, (self.posx, self.posy), self.radius)
        self.firstTime = 1

    #Displaying the ball on the screen 
    def display(self):
        self.ball = pygame.draw.circle(screen, self.color, (self.posx, self.posy), self.radius)

    #Updating the balls position after collision 
    def update(self):
        self.posx += self.speed * self.xFac
        self.posy += self.speed * self.yFac
        # If the ball hits the top or bottom surfaces, 
            # then the sign of yFac is changed and 
            # it results in a reflection
        if self.posy <= 0:
            self.yFac *= -1

        # Ball reached the bottom
        if self.posy >= HEIGHT:
            return True  
        
        # Ball reached sides or top 
        if self.posx <= 0 and self.firstTime:
            self.xFac *= -1
        elif self.posx >= WIDTH and self.firstTime:
            self.xFac *= -1
        else:
            return False
    #resets ball postion after hitting bottom 
    def reset(self):
        self.posx = WIDTH // 2
        self.posy = HEIGHT // 2
        self.xFac *= -1
        self.firstTime = 1

    def hit(self):
        self.yFac *= -1

    def getRect(self):
        return self.ball

#The class for the brick objects 
class Brick:
    #Initializing the position, width, height, color, and hit count of the brick objects 
    def __init__(self, posx, posy, width, height, color, hit_count):
        self.posx = posx
        self.posy = posy
        self.width = width
        self.height = height
        self.color = color
        self.hit_count = hit_count
        self.rect = pygame.Rect(posx, posy, width, height)

    #Displaying the brick objects on the screen 
    def display(self):
        pygame.draw.rect(screen, self.color, self.rect)

    #defines collision of the ball and the brick objects 
    def check_collision(self, ball_rect):
        return self.rect.colliderect(ball_rect)
    
#Defines the start menu: Text displayed, time it starts, color and font, and screen color 
def show_start_menu():
    screen.fill(HOTPINK)
    title_text = font40.render("Brick Breaker", True, WHITE)
    start_text = font20.render("Press SPACE to start the game", True, WHITE)
    instruction_text = font20.render("Use arrow keys (< & >) to move the paddle", True, WHITE)
    instruction_text2= font10.render("You have 3 lives", True, WHITE)
    screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 80))
    screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, HEIGHT // 2 - 20))
    screen.blit(instruction_text, (WIDTH // 2 - instruction_text.get_width() // 2, HEIGHT // 2 + 20))
    screen.blit(instruction_text2, (WIDTH // 2 - instruction_text2.get_width() // 2, HEIGHT // 2 + 60))
    pygame.display.update()
    pygame.time.wait(1000)
    waiting_for_start = True
    while waiting_for_start:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                waiting_for_start = False
#Defines the instructions for the game: the rules and how to start the game 
def show_instructions():
    screen.fill(HOTPINK)
    instruction_text = font20.render("Level 1: Break all the bricks to win!", True, WHITE)
    instruction_text2 = font20.render("Level 2: Bricks with different hit counts", True, WHITE)
    instruction_text3 = font20.render("Press SPACE to start the game", True, WHITE)
    screen.blit(instruction_text, (WIDTH // 2 - instruction_text.get_width() // 2, HEIGHT // 2 - 40))
    screen.blit(instruction_text2, (WIDTH // 2 - instruction_text2.get_width() // 2, HEIGHT // 2))
    screen.blit(instruction_text3, (WIDTH // 2 - instruction_text3.get_width() // 2, HEIGHT // 2 + 40))
    pygame.display.update()
    pygame.time.wait(1000)
    waiting_for_start = True
    while waiting_for_start:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                waiting_for_start = False

#Defines the win screen: text that shows the user that they have won the game, and initializes the font, position, and color of the text 
def show_win_screen():
    screen.fill(HOTPINK)
    win_text = font20.render("Congratulations! You won Level 1!", True, WHITE)
    instruction_text = font20.render("Press SPACE to start Level 2", True, WHITE)
    screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, HEIGHT // 2 - 20))
    screen.blit(instruction_text, (WIDTH // 2 - instruction_text.get_width() // 2, HEIGHT // 2 + 20))
    pygame.display.update()
    pygame.time.wait(1000)
    waiting_for_start = True
    while waiting_for_start:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                waiting_for_start = False
#Defines the loss screen: Shows the user that they have lost the game and why, and intializes the font, position, and color of the text 
def show_loss_screen():
    screen.fill(HOTPINK)
    loss_text = font20.render("Game over! You lost all three lives.", True, WHITE)
    instruction_text = font20.render("Press SPACE to go back to the start screen or click the X to exit", True, WHITE)
    screen.blit(loss_text, (WIDTH // 2 - loss_text.get_width() // 2, HEIGHT // 2 - 20))
    screen.blit(instruction_text, (WIDTH // 2 - instruction_text.get_width() // 2, HEIGHT // 2 + 20))
    pygame.display.update()
    pygame.time.wait(1000)
    waiting_for_start = True
    while waiting_for_start:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                waiting_for_start = False

#Runs the game: also shows three lives 
def run_game(level):
    running = True
    bricks = []
    lives = 3

    # Defining the objects: Stricker, ball, bricks 
    geek1 = Striker(400, 560, 100, 10, 12, PINK) 
    ball = Ball(WIDTH // 2, HEIGHT // 2, 7, 2.5, WHITE)  
    brick_width = 80
    brick_height = 20

    #Initializes the colors of the bricks on levels 1 and 2 
    if level == 2:
        brick_colors = [PINK, DARKPINK, LIGHTPINK]
        brick_hit_counts = [1, 2, 1]
    else:
        brick_colors = [PINK]
        brick_hit_counts = [1]

    #Array of bricks used in the game 
    for i in range(10):
        for j in range(5):
            brick_color = brick_colors[j % len(brick_colors)]
            hit_count = brick_hit_counts[j % len(brick_hit_counts)]
            brick = Brick(i * (brick_width + 10), j * (brick_height + 10), brick_width, brick_height, brick_color, hit_count)
            bricks.append(brick)

    #Defines the user 
    listOfGeeks = [geek1]
    geek1YFac = 0

    #Controls for operating the striker 
    while running:
        screen.fill(HOTPINK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    geek1YFac = -1
                if event.key == pygame.K_RIGHT:
                    geek1YFac = 1
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    geek1YFac = 0

         # Collision detection
        for geek in listOfGeeks:
            if pygame.Rect.colliderect(ball.getRect(), geek.getRect()):
                ball.hit()

        for brick in bricks:
            if brick.check_collision(ball.getRect()):
                brick.hit_count -= 1
                if brick.hit_count <= 0:
                    bricks.remove(brick)
                ball.yFac *= -1
                break

        #Updates the lives shown on screen: if the ball reaches the bottom, one life is lost 
        ball.update()
        if ball.posy >= HEIGHT:
            lives -= 1
            if lives == 0:
                show_loss_screen()
                return False
            else:
                ball.reset()

        #displays the bricks on screen 
        for brick in bricks:
            brick.display()

        geek1.update(geek1YFac)
        point = ball.update()

        #Defines the lives and when the loss screen shows 
        if point:
            lives -= 1
            if lives == 0:
                show_loss_screen()
                return False
            else:
                ball.reset()

        #The displays of the user, score/lives, and the ball 
        geek1.display()
        ball.display()
        geek1.displayScore("Lives: ", lives, WIDTH - 100, 550, WHITE)

        pygame.display.update()
        clock.tick(FPS)
        
        #Defines the music that happens once you win the game and shows the win screen 
        if len(bricks) <= 0:
            if level == 1:
                mixer.music.load("The Gummy Bear Song.mp3")
                mixer.music.play()
                show_win_screen()
            return True

#Defines the music that plays during the game 
def main():
    mixer.music.load("Dance The Night.mp3")
    mixer.music.play()
    show_instructions()
    show_start_menu()
    while True:
        if run_game(1):
            show_instructions()
            if not run_game(2):
                mixer.music.load("Dance The Night.mp3")
                mixer.music.play()
                show_start_menu()
    


if __name__ == "__main__":
    main()
